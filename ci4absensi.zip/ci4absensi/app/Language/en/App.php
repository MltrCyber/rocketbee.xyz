<?php
return [
    'new' => 'Tambah Data',
    'add'  =>'Tambahkan Data',
    'edit'  => 'Ubah Data',
    'update' => 'Perbarui Data',
    'delete' => 'Hapus Data',
    'copy' => 'Salin',
    'save'  => 'Simpan Data',
    'confirm' => 'Konfirmasi',
    'cancel'  => 'Batalkan',
    'remove-title' => 'Apakah Anda yakin dengan proses penghapusan?',
    'remove-text' => 'Anda tidak dapat kembali setelah konfirmasi',
    'insert-success' => 'Data telah dimasukkan dengan sukses',
    'insert-error' => 'Kesalahan penyisipan!',
    'update-success' => 'Berhasil diperbarui',
    'update-error' => 'Perbarui kesalahan!',
    'delete-success' =>'Berhasil dihapus',
    'delete-error' => 'Hapus kesalahan!',
 
];