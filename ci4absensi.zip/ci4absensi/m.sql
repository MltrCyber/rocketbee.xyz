CREATE TRIGGER update_total_bayar
AFTER INSERT, UPDATE ON transaksi
FOR EACH ROW
BEGIN
    DECLARE total INT;

    SELECT SUM(harga) INTO total
    FROM transaksi
    WHERE id_barang = NEW.id_barang;


    UPDATE pembayaran1
    SET total_bayar = total
    WHERE id_barang = NEW.id_barang;
END;
